Names: Anisha Bhattacharya
	Godbless Chille
URID: 31564472-Anisha
	31528986-Godbless
NETID: abhatta9-Anisha
	gchille-Godbless

Contact information: abhatta9@u.rochester.edu
			gchille@u.rochester.edu


LAB5
For this lab, we implemented 19 common methods for the URArrayList class as well as the URLinkedList class.
We had 8 additional methods which are well explained in the source file that contains the comments as well as the comments(for both classes).
Some of the methods include;printList, biggerListCapacity,etc. Please refer to the source file for more.
We checked for all errors including, but not limited to; NullPointerException, IndexOutOfBoundsException, etc(for both classes)

Please note: In the URLinkedList class, we printed the list from the top to the bottom, that is, head was printed first and then the last elements were printed last.
		More to that, we made sure that the head has index zero and all the elements supersede the head when it comes to printing.

		In the URArrayList class, we printed all the elements with their respective indices, please run the program to see how this works.

Please run the program and refer to the comments in the files to see how this works.

Extra-Credit work:
We decided to create a method which doubled the capacity of the list so that the list can contain a very large number of elements.

Thank you for your time.

