Name: Godbless Chille
 		Anisha Bhattacharya
NETID: gchille
		abhatta9
NETID no. 31528986
			31564472
email: gchille@u.rochester.edu
		abhatta9@u.rochester.edu

Lab: 6:15-7:30pm

In this lab, we implemented methods to delete, to traverse through the bninary search tree as well as looking up for an element in the binary search tree.

PLease refer to the comments in the source files.

Thank you.
