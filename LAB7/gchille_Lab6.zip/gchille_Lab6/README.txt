Name: Godbless Chille
Lab Partner: Anisha Bhattacharya
CSC 172 LAB 6
NETID: gchille
NETID Lab Partner: abhatta9
email: gchille@u.rochester.edu
lab partner email: abhatta9@u.rochester.edu

Lab: 6:15-7:30pm

In this lab, we implemented a total of four methods based on the given interface.
Please read the comments as written in the source file.
For this lab, I created a linked list of the same type as that of lab5 and added elements to it while using the LIFO
(Last-In-First-Out) principle. I simply called the methods, as required by the question. Refer to the source file for 
the description.

In addition to the required, I implemented a variable called sizeofStack which increased and decreased
as I pushed and popped elements, respectively. I found it useful because it helped me verify that the stack is empty
if all the elements have been popped out.
The variable topOfStack was useful in determining what was on the top of the stack at the moment. It always pointed to the
element that was added last in the stack.


