
public class myStack<AnyType> implements Stack<AnyType> {

	int sizeOfStack = 0;
	int topOfStack = -1;
	// URLinkedList<AnyType> top = null;
	URLinkedList<AnyType> myNewList;

	public myStack(AnyType k) {
		myNewList = new URLinkedList<AnyType>(k);

	}
	//check if the stack is empty
	public boolean isEmpty() {

		if (sizeOfStack == 0) {
			return true;
		}
		return false;
	}
	//add elements to the stack
	public void push(AnyType x) {
		myNewList.addFirst(x);
		topOfStack++;
		sizeOfStack++;
		System.out.println("Element " + sizeOfStack + " is pushed into stack");

	}
	//remove elements from the queue in the LIFO principle
	public AnyType pop() {

		if (isEmpty()) {
			return null;
		}
		sizeOfStack--;
		topOfStack--;

		return myNewList.pollFirst();

	}
	//check what is at the top of the stack
	public AnyType peek() {
		if (isEmpty()) {

			System.out.println("empty stack");
			return null;
		}
	
		return myNewList.peekFirst();
	}
	//main method with test cases
	public static void main(String args[]) {
		myStack theStack = new myStack(10);
		theStack.push(1);
		theStack.push(2);
		theStack.push(3);
		theStack.push(4);
		System.out.println("now the current size of the stack is "+ theStack.sizeOfStack);
		System.out.println("pop out element " + "'" + theStack.pop() + "'");
		System.out.println("pop out element " + "'" + theStack.pop() + "'");
		System.out.println("pop out element " + "'" + theStack.pop() + "'");
		System.out.println("pop out element " + "'" + theStack.pop() + "'");
		System.out.println("the top of the stack contains " + theStack.peek()+ " and the size is "+ theStack.sizeOfStack);
		System.out.println();
		
	}

}
