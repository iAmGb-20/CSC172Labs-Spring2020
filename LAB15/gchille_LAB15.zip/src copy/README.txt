CSC172 LAB 15

Names:
	Anisha Bhattacharya
	Godbless Chille
NETID: abhatta9
		gchille
LAB TA: Sidhant Bendre


		In this lab, we implemented a simple Change program which used dynamic programming to return the minimum number of chnage needed.
		We use makeChange method which was the main methid that returned an array containing the change that is going to be required, then implemented
		recMakeChange() function which simply had recursive calls to solve this problem.
		On top of that, we had a helper method known as expandArray().

		To run: Enter javac *.java
		Then enter Java CoinMain <amount>
		
		example:
		Java CoinMain 100000
Thanks.
