Name: Godbless Chille

Name: Anisha Bhattacharya

CSC 172 LAB 12

NETID: gchille

NETID: abhatta9

NETID no. 31528986

NETID no. 31564472

email: gchille@u.rochester.edu

email: abhatta9@u.rochester.edu


 

In this lab, we implemented a Graphs which consisted of an adjacency matrix. Inside the graph class there is a class called "AdjArray" which implements AdjList.

The AdjList acts like an iterator which goes through the graph. The show() method is used to print out the list. The example graphs for testing are based on the required examples from the pdf.

Thanks
