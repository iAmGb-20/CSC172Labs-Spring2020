public class Edge{
    public final int v, w; // an edge from v to w
         public Edge(int v, int w) { 

            this.v = v;
            this.w = w;
             // your code here }
            }
    }